
// seoPro.page.Home = function(config) {
//     config = config || {};
//     Ext.applyIf(config,{
//         components: [{
//             xtype: 'seopro-panel-home'
//             ,renderTo: 'seopro-panel-home-div'
//         }]
//     }); 
//     seoPro.page.Home.superclass.constructor.call(this,config);
// };
// Ext.extend(seoPro.page.Home,MODx.Component);
// Ext.reg('seopro-page-home',seoPro.page.Home);