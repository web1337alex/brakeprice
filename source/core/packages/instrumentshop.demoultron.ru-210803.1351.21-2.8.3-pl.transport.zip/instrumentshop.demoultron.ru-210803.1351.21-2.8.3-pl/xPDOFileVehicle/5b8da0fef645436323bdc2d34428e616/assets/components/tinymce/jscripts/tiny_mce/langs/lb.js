tinyMCE.addI18n({lb:{
common:{
edit_confirm:"D\u00EBsen Textber\u00E4ich mat WYSIWYG beaarbechten?",
apply:"Iwwerhuelen",
insert:"Af\u00FCgen",
update:"Aktualis\u00E9ieren",
cancel:"Ofbriechen",
close:"Zoumaachen",
browse:"Duerchsichen",
class_name:"CSS-Klass",
not_set:"- ondefin\u00E9iert -",
clipboard_msg:"Kop\u00E9ieren, Ausschneiden an Af\u00FCgen sinn am Mozilla Firefox net m\u00E9iglech.\nW\u00EBllt Dir m\u00E9i iwwert d\u00EBse Problem gewuer ginn?",
clipboard_no_support:"G\u00EBtt momentan net an \u00C4rem Browser \u00EBnnerst\u00EBtzt. Benotzt wann ech gelift d'Tastekombinatiounen.",
popup_blocked:"Leider huet \u00C4re Popup-Blocker eng F\u00EBnster \u00EBnnerdr\u00E9ckt, d\u00E9i fir d'Funktion\u00E9iere vun d\u00EBsem Programm n\u00E9ideg ass. Deaktiv\u00E9iert wann ech gelift de Popup-Blocker fir d\u00EBs S\u00E4it.",
invalid_data:"Feeler: Dir hutt ong\u00FClteg W\u00E4erter uginn (rout mark\u00E9iert).",
more_colors:"Weider Fuerwen"
},
contextmenu:{
align:"Ausriichtung",
left:"L\u00E9nks align\u00E9iert",
center:"Zentr\u00E9iert",
right:"Riets align\u00E9iert",
full:"B\u00E9ids\u00E4iteg align\u00E9iert"
},
insertdatetime:{
date_fmt:"%d.%m.%Y",
time_fmt:"%H:%M:%S",
insertdate_desc:"Datum af\u00FCgen",
inserttime_desc:"Z\u00E4it af\u00FCgen",
months_long:"Januar,Februar,M\u00E4erz,Abr\u00EBll,Mee,Juni,Juli,August,September,Oktober,November,Dezember",
months_short:"Jan,Feb,M\u00E4erz,Abr,Mee,Juni,Juli,Aug,Sept,Okt,Nov,Dez",
day_long:"Sonndeg,M\u00E9indeg,D\u00EBnschdeg,M\u00EBttwoch,Donneschdeg,Freideg,Samschdeg,Sonndeg",
day_short:"So,M\u00E9,D\u00EB,M\u00EB,Do,Fr,Sa,So"
},
print:{
print_desc:"Dr\u00E9cken"
},
preview:{
preview_desc:"Virschau"
},
directionality:{
ltr_desc:"Schr\u00EBft vu l\u00E9nks no riets",
rtl_desc:"Schr\u00EBft vu riets no l\u00E9nks"
},
layer:{
insertlayer_desc:"Neie Layer af\u00FCgen",
forward_desc:"No vir r\u00E9ckelen",
backward_desc:"No hanne r\u00E9ckelen",
absolute_desc:"Absolut Position\u00E9ierung",
content:"Neie Layer..."
},
save:{
save_desc:"Sp\u00E4icheren",
cancel_desc:"All d'\u00C4nnerungen ewechpuchen"
},
nonbreaking:{
nonbreaking_desc:"Gesch\u00FCtzt Leerzeechen af\u00FCgen"
},
iespell:{
iespell_desc:"Spellchecker",
download:"ieSpell konnt net fonnt ginn. W\u00EBllt Dir en install\u00E9ieren?"
},
advhr:{
advhr_desc:"Trennlinn"
},
emotions:{
emotions_desc:"Smileyen"
},
searchreplace:{
search_desc:"Sichen",
replace_desc:"Sichen/Ersetzen"
},
advimage:{
image_desc:"Bild af\u00FCgen/ersetzen"
},
advlink:{
link_desc:"Link af\u00FCgen/beaarbechten"
},
xhtmlxtras:{
cite_desc:"Quellenzit\u00E9ierung",
abbr_desc:"Ofkierzung",
acronym_desc:"Akronym",
del_desc:"Gel\u00E4schten Text",
ins_desc:"Agef\u00FCgtenen Text",
attribs_desc:"Attributer af\u00FCgen/beaarbechten"
},
style:{
desc:"CSS-Styles beaarbechten"
},
paste:{
paste_text_desc:"Als normalen Text af\u00FCgen",
paste_word_desc:"Mat Format\u00E9ierungen (aus dem Word) af\u00FCgen",
selectall_desc:"Alles auswielen",
plaintext_mode_sticky:"Beim Af\u00FCge g\u00EBtt elo just den Text ouni Format\u00E9ierungen iwwerholl. Nach eng K\u00E9ier klicken, fir an den normale Modus zer\u00E9ckzewiesselen. Nodeem s Dir eppes agef\u00FCgt hutt, g\u00EBtt automatesch nees an den normale Modus gewiesselt.",
plaintext_mode:"Beim Af\u00FCge g\u00EBtt elo just den Text ouni Format\u00E9ierungen iwwerholl. Nach eng K\u00E9ier klicken, fir an den normale Modus zer\u00E9ckzewiesselen."
},
paste_dlg:{
text_title:"Dr\u00E9ckt op \u00C4rer Tastatur Ctrl+V, fir den Text an ze f\u00FCgen.",
text_linebreaks:"Zeilen\u00EBmbr\u00EBch b\u00E4ibehalen",
word_title:"Dr\u00E9ckt op \u00C4rer Tastatur Ctrl+V, um den Text an ze f\u00FCgen."
},
table:{
desc:"Tabell erstellen/beaarbechten",
row_before_desc:"Zeil uewerhalb af\u00FCgen",
row_after_desc:"Zeil \u00EBnnerhalb af\u00FCgen",
delete_row_desc:"Zeil l\u00E4schen",
col_before_desc:"Spalt l\u00E9nks af\u00FCgen",
col_after_desc:"Spalt riets af\u00FCgen",
delete_col_desc:"Spalt l\u00E4schen",
split_cells_desc:"Verbonnen Zellen trennen",
merge_cells_desc:"Zellen verbannen",
row_desc:"Eegeschaften vun der Zeil",
cell_desc:"Eegeschaften vun der Zell",
props_desc:"Eegeschaften vun der Tabelle",
paste_row_before_desc:"Zeil uewerhalb aus der Zw\u00EBschenoflag af\u00FCgen",
paste_row_after_desc:"Zeil \u00EBnnerhalb aus der Zw\u00EBschenoflag af\u00FCgen",
cut_row_desc:"Zeil ausschneiden",
copy_row_desc:"Zeil kop\u00E9ieren",
del:"Tabelle l\u00E4schen",
row:"Zeil",
col:"Spalt",
cell:"Zell",
cellprops_delta_width:"150"
},
autosave:{
unload_msg:"\u00C4r \u00C4nnerungen gi verluer, wann Dir d'S\u00E4it verloosst.",
restore_content:"Automatesch gesp\u00E4icherten Inhalt recuper\u00E9ieren.",
warning_message:"Wann Dir dee gesp\u00E4icherten Inhalt recuper\u00E9iert, verl\u00E9iert Dir de ganzen Inhalt dee grad am Editor ass.\n\nW\u00EBllt Dir de gesp\u00E4icherten Inhalt s\u00E9cher recuper\u00E9ieren?."
},
fullscreen:{
desc:"Vollbildschierm"
},
media:{
desc:"Multimedia-Inhalt abannen/beaarbechten",
edit:"Multimedia-Abettung beaarbechten"
},
fullpage:{
desc:"Dokument-Eegeschaften"
},
template:{
desc:"Virgef\u00E4erdegte Virlageninhalt af\u00FCgen"
},
visualchars:{
desc:"Siichtbarkeet vun de Steierzeechen un/aus"
},
spellchecker:{
desc:"Spellchecker un/aus",
menu:"Konfiguratioun vum Spellchecker",
ignore_word:"Wuert ignor\u00E9ieren",
ignore_words:"All ignor\u00E9ieren",
langs:"Sproochen",
wait:"Wann ech gelift waarden...",
sug:"Virschl\u00E9i",
no_sug:"Keng Virschl\u00E9i",
no_mpell:"Keng Orthographiefeeler fonnt."
},
pagebreak:{
desc:"S\u00E4iten\u00EBmbroch af\u00FCgen"
},
advlist:{
types:"Typen",
def:"Standard",
lower_alpha:"Kleng Buschtawen",
lower_greek:"Kleng griichesch Buschtawen",
lower_roman:"Kleng r\u00E9imech Zuelen",
upper_alpha:"Grouss Buschtawen",
upper_roman:"Grouss r\u00E9imech Zuelen",
circle:"Krees",
disc:"Scheif",
square:"Quadrat"
}}});