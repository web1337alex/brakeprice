tinyMCE.addI18n('id.modxlink',{
    link_desc:"Insert/edit link"
});