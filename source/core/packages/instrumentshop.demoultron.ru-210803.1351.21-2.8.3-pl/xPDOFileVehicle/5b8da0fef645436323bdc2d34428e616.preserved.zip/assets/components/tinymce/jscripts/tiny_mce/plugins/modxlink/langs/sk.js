tinyMCE.addI18n('sk.modxlink',{
    link_desc:"Insert/edit link"
});