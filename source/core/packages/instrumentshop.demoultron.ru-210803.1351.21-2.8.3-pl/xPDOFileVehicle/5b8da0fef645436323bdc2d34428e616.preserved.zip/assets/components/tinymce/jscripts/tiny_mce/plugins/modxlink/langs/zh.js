tinyMCE.addI18n('zh.modxlink',{
    link_desc:"Insert/edit link"
});