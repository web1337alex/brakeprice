tinyMCE.addI18n('ps.modxlink',{
    link_desc:"Insert/edit link"
});