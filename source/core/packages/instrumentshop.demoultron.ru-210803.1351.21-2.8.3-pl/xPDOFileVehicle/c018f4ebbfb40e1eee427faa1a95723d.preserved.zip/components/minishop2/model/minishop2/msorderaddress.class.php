<?php
class msOrderAddress extends xPDOSimpleObject {}
